// Next Steps

// *** Search Bar Input size and styling - (Google remove default styling "input") 
// *** Search Button size and styling - (Google remove default styling button)
// *** Put h2 and search bar in div, put class on div, put background-color on div - (Google background transparency/opacity - "background-opacity: 90%")

// Style <a> element (remove default styling) 

// API DOCUMENTATION: https://developer.ticketmaster.com/products-and-docs/apis/discovery-api/v2/#search-events-v2

// freecodecamp.org

// Instructions
// Make an array of workouts called workouts (up to five)

// const workouts = ['bench', 'squats', 'deadlifts', 'curls', 'overhead press'];

// const chores = ['laundry', 'vaccuuming', 'sweeping', 'dishes'];

// // create a function called "addsText" that adds " is done" to the end of each workout in the array

function addsTextToEachItem(arrayOfItems) {
  arrayOfItems.forEach(function(eachItemInTheArray) {
    
  });
};

// // run the function twice, once for each array we created.
// addsTextToEachItem(workouts);
// addsTextToEachItem(chores);

//--------------------------//
//--------------------------//

const movie = {
	title: 'Scariest Movie Ever',
	genre: 'Horror',
	rating: 'R',
	director: 'M. Night Shamaylan',
	mainCharacter: 'Brad Pitt',
	length: '2 hours 20 minutes',
	releaseDate: '02/01/2020',
	inTheaters: true
};

const movies = [{
	title: 'Happy Gilmore',
	genre: 'Horror',
	rating: 'R',
	director: 'M. Night Shamaylan',
	mainCharacter: 'Brad Pitt',
	length: '2 hours 20 minutes',
	releaseDate: '02/01/2020',
	inTheaters: true
},{
	title: 'Billy Madison',
	genre: 'Horror',
	rating: 'R',
	director: 'M. Night Shamaylan',
	mainCharacter: 'Brad Pitt',
	length: '2 hours 20 minutes',
	releaseDate: '02/01/2020',
	inTheaters: true
},{
	title: 'Titanic',
	genre: 'Horror',
	rating: 'R',
	director: 'M. Night Shamaylan',
	mainCharacter: 'Brad Pitt',
	length: '2 hours 20 minutes',
	releaseDate: '02/01/2020',
	inTheaters: true
},{
	title: 'Star Wars',
	genre: 'Horror',
	rating: 'R',
	director: 'M. Night Shamaylan',
	mainCharacter: 'Brad Pitt',
	length: '2 hours 20 minutes',
	releaseDate: '02/01/2020',
	inTheaters: true
}];


// const movieTitle = 'Star Wars';

// let weights = ['120lb', '60lb', '20lb', '45lb', '160lb'];

// const message = 'I can lift ';

// function doingCurles(dumbbells) {
// 	// weights = ['cheeseburgers', 'french fries'];
// 	dumbbells.forEach(dumbbell => {
//     		console.log(weights);
//   	});
// };

// doingCurles(weights);


// printMovieTitle(movieTitle);

// declare a function called "sayItsGood". We need to pass in a list of movies to the function. For each movie in the list, the function will add " is good!!" to the end of each movie title.

// function sayItsGood(array) {
// 	array.forEach(movie => {
// 		console.log(movie.title + " is good!!");
// 	});
// };

// sayItsGood(movies);


// declare a function called 'addThese'. The function will take two placeholders, 'a' and 'b'. The function should return the sum of a and b. 

function addThese(a,b) {
 	return a + b;
}

console.log(addThese(436, 572));


